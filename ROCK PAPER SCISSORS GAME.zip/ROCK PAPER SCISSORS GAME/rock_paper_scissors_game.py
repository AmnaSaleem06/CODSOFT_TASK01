import random
rock = '''  
      ,--.--._
------" _, \___)
        / _/____)
        \//(____)
------\     (__)
       `-----"
'''

paper = '''  
         _______
      ---'   ____)____
                ______)
                _______)
               _______)
      ---.__________)
      '''

scissors = ''' 
         _______
      ---'   ____)____
                ______)
             __________)
            (____)
      ---.__(___)
      '''

game_images = [rock, paper, scissors]
user_scores = 0
computer_scores = 0

print ("WELCOME TO ROCK, PAPER, SCISSORS GAME!")
print (" CREDITS \n Amna Saleem \n Python Programming Intern - CODSOFT")

#TUTORIAL OF THE GAME
print ('''
    _ _        _                     _ 
    | |       | |           (_)     | |
    | |_ _   _| |_ ___  _ __ _  __ _| |
    | __| | | | __/ _ \| '__| |/ _` | |
    | |_| |_| | || (_) | |  | | (_| | |
    \__|\__,_|\__\___/|_|  |_|\__,_|_|
            
            OFFICIAL RULES OF ROCK PAPER SCISSORS GAME!

            ROCK
            ,--.--._
    ------" _, \___)
            / _/____)
            \//(____)
    ------\     (__)
        `-----"
            The rock is when you place your hand into the form of a simple fist.

            PAPER
        ______
    ---'   ____)____
                ______)
                _______)
                _______)
    ---.__________)
            The paper is when you place your hand in an outstretched position.

            SCISSORS
        _______
    ---'   ____)____
                ______)
                __________)
            (____)
    ---.__(___)
            The scissors is when you hold your fist with your index and middle finger pointing outwards in a V shape.

            *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

            RULES OF ROCK, PAPER, SCISSORS GAME!
            The outcome is determined by three rules.
            1. Rock wins against scissors.
            2. Scissors win against paper.
            3. Paper wins against rock.

            *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

''')

# ROCK PAPER SCISSORS GAME

while True:
        
        user_choice = int (input ("What do you choose? Type 0 for rock, 1 for paper and 2 for scissors.\n"))
        if user_choice >= 3 or user_choice < 0:
            print ("You typed an invalid number. You lose!")
        else:
            print (game_images[user_choice])

            computer_choice = random.randint (0,2)
            print ("Computer chooses:")
            print (game_images[computer_choice])

            if user_choice == 0 and computer_choice == 2:
                user_scores += 1
                print ("You win!")

            elif computer_choice == 0 and user_choice == 2:
                computer_scores += 1
                print ("You lose!")

            elif computer_choice > user_choice:
                computer_scores += 1
                print ("You lose!")

            elif user_choice > computer_choice:
                user_scores += 1
                print ("You win!")

            elif user_choice == computer_choice:
                user_scores += 1
                computer_scores += 1
                print ("It's a draw!")

        print ('Do you want to continue playing. Type "Y" for yes and "N" for no. ')
        continue_game = input("Enter your choice.")
        if continue_game == "N":
            print (f"You won {user_scores} scores, whereas computer won {computer_scores}. ")
            if user_scores > computer_scores:
                print ("Congratulations! You win!")
            elif user_scores < computer_scores:
                print ("OOPS! You lose!")
            else:
                print ("You and computer have equal scores. Tie!")
            print ("Thank you for playing!")
            break
        




